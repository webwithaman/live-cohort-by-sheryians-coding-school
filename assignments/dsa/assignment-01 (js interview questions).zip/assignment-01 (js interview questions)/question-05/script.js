// Find Output of the Following Code:

let i = 1,
  j = 2,
  k = 3;

let m = i-- - j-- - k--;

console.log("i=" + i); // i=0
console.log("j=" + j); // j=1
console.log("k=" + k); // k=2
console.log("m=" + m); // m=-4
