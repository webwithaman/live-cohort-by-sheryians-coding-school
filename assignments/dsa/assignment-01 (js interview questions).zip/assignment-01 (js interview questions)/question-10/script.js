// Find Output of the Following Code:

let a = 1;

a = a++ + ++a * --a - a--;

console.log(a); // 5
