// Find Output of the Following Code:

let i = 0;

i = i++ + --i + ++i - i--;

console.log(i); // 0
