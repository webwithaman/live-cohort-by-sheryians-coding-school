// Find Output of the Following Code:

let m = 0,
  n = 0;

let p = --m * --n * n-- * m--;

console.log(p); // 1
