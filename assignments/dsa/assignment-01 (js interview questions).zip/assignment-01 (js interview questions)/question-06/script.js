// Find Output of the Following Code:

let a = 1,
  b = 2;

console.log(-b + ++a + ++b - -a); // 5
