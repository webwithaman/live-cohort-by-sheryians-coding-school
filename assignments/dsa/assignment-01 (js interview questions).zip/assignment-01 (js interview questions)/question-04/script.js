// Find Output of the Following Code:

let b = true;

b++;

console.log(b); // 2
