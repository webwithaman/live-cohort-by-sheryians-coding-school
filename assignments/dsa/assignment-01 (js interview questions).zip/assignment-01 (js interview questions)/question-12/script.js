// Find Output of the Following Code:

let i = 0,
  j = 0;

console.log(--i * i++ * ++j * j++); // 1
